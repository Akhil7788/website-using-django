from django.apps import AppConfig


class ServeConfig(AppConfig):
    name = 'serve'
